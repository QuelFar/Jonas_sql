<?php
    $hostname='localhost';
    $username='root';
    $password='';
    $db='skynet';

    $conexao = new mysqli($hostname,$username,$password,$db);
?>