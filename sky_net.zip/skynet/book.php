<?php
        
    include('conexao.php');

    if (isset($_POST['submit'])){
    //DADOS CLIENTE
    $cpf = $_POST['cpf'];
    $nome_completo = $_POST['nome_completo'];
    $email = $_POST['email'];
    $endereco = $_POST['endereco'];
    $telefone = $_POST['telefone'];
    $cidade = $_POST['cidade'];
    $estado = $_POST['estado'];
    $cep = $_POST['cep'];

    //DADOS RESERVA
    //$checkin = $_POST['checkin'];
    //$checkout = $_POST['checkout'];
    //$quarto = $_POST['quarto'];
    //$adulto = $_POST['adulto'];
    //$kid = $_POST['kid'];
    //------------------------------------------------------------

    $resultado = mysqli_query($conexao, "INSERT INTO cliente VALUES('$cpf', '$nome_completo', '$email', '$endereco', '$telefone', '$cidade', '$estado', '$cep')");

    };

    $conexao->close();    
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/style_2.css">

<title>Document</title>
</head>
<body>
<div class="image_background"></div> <!--DIV for image background-->
<header>
    <link rel="stylesheet" href="css/header.css">
    <div class="opc_header">
        <div class="logo_header">
            <p class="title_header">HOTEL SkyNet.</p>
        </div>
        <nav class="nav_header">
            <link rel="stylesheet" href="css/btn.css">
            <ul>
                <li class="align_li"><a href="home.html"><button class="btn_chroma">HOME</button></a></li>
                <li class="align_li"><a href="book.php"><button class="btn_chroma">BOOK NOW</button></a></li>
                <li class="align_li"><a href="forcompany.html"><button class="btn_chroma">FOR COMPANY</button></a></li>
            </ul>
        </nav>
    </div>
</header>
<main>
    <link rel="stylesheet" href="css/book_main.css">
    <link rel="stylesheet" href="css/form_book.css">
    <div class="main">
        <h1>Make your reservation here</h1>
        <br>
        <h3>Client's data</h3>
        <form action="book.php" method="post">
            <label for="nome">Full nome:</label>
            <input type="text" name="nome_completo" class="name_input">
            <br><br>
            <label for="cpf">CPF:</label>
            <input type="number" name="cpf" class="cpf_input
            ">
            <br><br>
            <label for="email">E-MAIL:</label>
            <input type="text" name="email" class="email_input">
            <br><br>
            <label for="telefone">Phone Number :</label>
            <input type="number" name="telefone" class="telefone_input">
            <br><br>
            <label for="endereco1">Addres 1:</label>
            <input type="text" name="endereco" class="endereco_input">
            <br><br>
            <label for="cidade">City:</label>
            <input type="text" name="cidade" class="cidade_input">
            <br><br>
            <label for="estado">State:</label>
            <input type="text" name="estado" class="estado_input">
            <br><br>
            <label for="cep">Zip code:</label>
            <input type="number" name="cep" class="cep_input">
            <br><br>
        <h3>Booking details</h3>
            <br><br>
            <label for="checkin">Check-In</label>
            <input type="date" name="checkin" class="checkin_input">
            <br><br>
            <label for="checkout">Check-Out</label>
            <input type="date" name="checkout" class="checkout_input">
            <br><br>
            <label for="tipo_quarto">Room types</label>
            <select name="tipo_quarto" name="quarto" class="quarto_input">
                <option value="">Select...</option>
                <option value="quarto_individual">Single room</option>
                <option value="quarto_duplo">Twin room</option>
                <option value="suite">Suite</option>
                <option value="suite_premium">Suite premium</option>
            </select>
            <br><br>
            <label for="adulto">Number of adults:</label>
            <select name="adulto" class="adulto_input">
                <option value="">Select...</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
            </select>
            <br><br>
            <label for="kid">Amount of child:</label>
            <select name="kid" class="kid_input">
                <option value="">Select...</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
            </select>
            <br><br>
            <input type="submit" name="submit" class="enviar">
            <br><br>
            <hr>
        </form>
</main>
<footer>
    <div class="footer">
       <div class="footer_um">
           <img src="images/logo.png" alt="" class="footer_img">
       </div>
       <div class="footer_dois">
           <h1 class="footer_h1">CONTACT</h1>
           <ul>
               <li class="footer_li">EMAIL: contato@skynet.com.br</li>
               <li class="footer_li">TELEPHONE : 3435-1234</li>
               <li class="footer_li">ADDRESS : Rua dos Alfineiros , N° 666</li>
               <li class="footer_li">&copy; ALL RIGHTS RESERVED</li>
           </ul>
       </div>
    </div>
</footer>
</body>
</html>